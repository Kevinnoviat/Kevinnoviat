const premiumUsers = [];

module.exports = premiumUsers;